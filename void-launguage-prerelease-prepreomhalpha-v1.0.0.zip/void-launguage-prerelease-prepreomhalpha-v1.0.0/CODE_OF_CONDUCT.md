This repository is a TC39 project and subscribes to its [code of conduct](https://tc39.es/code-of-conduct/). It is available at [https://tc39.es/code-of-conduct/](https://tc39.es/code-of-conduct/).

To ask a question or report an issue, please email [tc39-conduct-reports@googlegroups.com](mailto:tc39-conduct-reports@googlegroups.com).