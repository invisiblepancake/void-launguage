# Withdrawn Proposals

This list has moved [here](https://github.com/tc39/proposals/blob/HEAD/inactive-proposals.md).
